name = "NonLinLocPy"
__version__ = "0.0.1"
__description__ = "NonLinLocPy - A package for reading NonLinLoc data into python"
__license__ = "MIT"
__author__ = "Tom Hudson"
__email__ = "thomas.hudson@earth.ox.ac.uk"
import NonLinLocPy.read_nonlinloc
